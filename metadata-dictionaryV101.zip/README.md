# ng1-seed-app
Angular 1 Seed application

## Installation
This App takes care of all basic setup of application for dhis, simply clone it and start development.


# metadata-dictionary
