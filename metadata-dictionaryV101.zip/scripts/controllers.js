/* global angular */

'use strict';

/* Controllers */
var appSeedControllers = angular.module('appSeedControllers', [])

.controller('MainController', function($scope, $window, ModalService) {
	
})
