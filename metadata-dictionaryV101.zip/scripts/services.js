/* global angular */

'use strict';

/* Services */

var appSeedServices = angular.module('appSeedServices', ['ngResource']);

