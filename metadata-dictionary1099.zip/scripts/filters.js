'use strict';

/* Filters */

var appSeedFilters = angular.module('appSeedFilters', []);
