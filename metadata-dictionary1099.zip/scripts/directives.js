'use strict';

/* Directives */

var appSeedDirectives = angular.module('appSeedDirectives', []);
